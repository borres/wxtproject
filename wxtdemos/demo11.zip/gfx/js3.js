function toggleGadget(elt)
{
    // header(0) and content(1)
    contentElt=elt.parentNode.getElementsByTagName('div')[1];
    
    if(elt.getAttribute("class")=="off")
    {
        contentElt.style.display='block';
        elt.setAttribute("class","on");        
    }
    else
    {
        contentElt.style.display='none';
        elt.setAttribute("class","off");
    }
} 

function toggleExpandSimple(elt)
{
    // header(0) and content(1)
    contentElt=elt.parentNode.getElementsByTagName('div')[1];
    
    if(elt.getAttribute("class")=="off")
    {
        contentElt.style.display="none";
        elt.setAttribute("class","on");
    }
    else
    {
        contentElt.style.display="block";
        elt.setAttribute("class","off");
    }
} 

function toggleExpandAjax(address,elt)
{
    // header(0) and content(1)
    contentElt=elt.parentNode.getElementsByTagName('div')[1];
    
    if(elt.getAttribute("class")=="off")
    {
        contentElt.innerHTML=" ";
        elt.setAttribute("class","on");
    }
    else
    {
        new Ajax.Request(address,
                 {method:'get',
                 onSuccess:function(transport){
                    var T=transport.responseText;
                    var pos1=T.indexOf('<pre');
                    var pos2=T.lastIndexOf('</pre');
                    if ((pos1 !=-1) && (pos2 > pos1))
                        T=T.substring(pos1,pos2+6);
                    contentElt.innerHTML=T;
                 },
                 onFailure:function(){contentElt.innerHTML="Could not access content"}
                 });
        elt.setAttribute("class","off");
    }
}  
