/*
Minimalistic library for wxt
- popup as in PI popup:
     simplepopup(url,wname,wstyle)
- toggling visibility of
    - ajaxexpansions as in PI expand:
      toggleExpandAjax(address,elt)
    - simple inline expansions as in PI expandsimple:
      toggleExpandSimple(elt)
    - gadget expansion as in PI gadget:
      toggleGadget(elt)
Relying on prototype.js (http://www.prototypejs.org/)

style classes on and off must be defined

B.Stenseth 2010.
*/

// ------------  popup ------------------
//popup
  function simplepopup(theURL,wname,wstyle)
  {
  	if(wstyle=='*')
  		wstyle='scrollbars=yes,resizable=yes,width=600,height=600,status=no';
  	try{
  		newwindow=window.open(theURL, wname, wstyle);
  		if (window.focus) {newwindow.focus()}
  	}
  	catch(E){
  		alert('You may have blocked popups');
	  }
  }
//eofpopup

//------------- toggle view ------------------
function toggleGadget(elt)
{
    toggleExpandSimple(elt);
} 

function toggleExpandSimple(elt)
{
    contentElt=elt.parentNode.getElementsByTagName('div')[1];    
    if(elt.getAttribute("class")=="off")
    {
        contentElt.style.display="block";
        elt.setAttribute("class","on");
    }
    else
    {
        contentElt.style.display="none";
        elt.setAttribute("class","off");
    }
} 

function toggleExpandAjax(address,elt)
{
    contentElt=elt.parentNode.getElementsByTagName('div')[1];    
    if(elt.getAttribute("class")=="off")
    {
        new Ajax.Request(address,
                 {method:'get',
                 onSuccess:function(transport){
                    var T=transport.responseText;
                    var pos1=T.indexOf('<pre');
                    var pos2=T.lastIndexOf('</pre');
                    if ((pos1 !=-1) && (pos2 > pos1))
                        T=T.substring(pos1,pos2+6);
                    contentElt.innerHTML=T;
                 },
                 onFailure:function(){contentElt.innerHTML="Could not access content"}
                 });
        elt.setAttribute("class","on");
    }
    else
    {
        contentElt.innerHTML=" ";
        elt.setAttribute("class","off");
    }
} 