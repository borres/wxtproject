/*
Minimalistic library for wxt
- popup:
     simplepopup(url,wname,wstyle)
	 used by PI: popup
- ajaxbased expand/unexpand:
     expand(address,targetNode)
     unexpand(address,targetNode)
	 Relying on prototype.js (http://www.prototypejs.org/)
	 used by PI: expand
B.Stenseth 2009.
*/

// ------------  popup ------------------
//popup
  function simplepopup(theURL,wname,wstyle)
  {
  	if(wstyle=='*')
  		wstyle='scrollbars=yes,resizable=yes,width=600,height=600,status=no';
  	try{
  		newwindow=window.open(theURL, wname, wstyle);
  		if (window.focus) {newwindow.focus()}
  	}
  	catch(E){
  		alert('You may have blocked popups');
	  }
  }
//eofpopup

//------------- expansion ------------------
// dependent of style-class: onoff for visible effect
// and prototype.js v1.6 from http://www.prototypejs.org/
//expand
function expand(address,targetNode){
	new Ajax.Request(address,
	                 {method:'get',
					 onSuccess:function(transport){
						var T=transport.responseText;
						var pos1=T.indexOf('<pre');
						var pos2=T.lastIndexOf('</pre');
						if ((pos1 !=-1) && (pos2 > pos1))
							T=T.substring(pos1,pos2+6);
						T='<span class="expand" '+
						  'onclick="unexpand(\''+address+
						  '\',this.parentNode)"><span class="off">-</span></span>'
						  +T;
						targetNode.innerHTML=T;
					 },
					 onFailure:function(){targetNode.innerHTML="Could not access content"}
					 });
}
//eofexpand
//unexpand
function unexpand(address,targetNode){
    T='<span class="expand" '+
    'onclick="expand(\''+address+'\',this.parentNode);"><span class="on">+</span></span>';
    targetNode.innerHTML=T;
}
//eofunexpand

function toggleGadget(elt)
{
    // header(0) and content(1)
    contentElt=elt.parentNode.getElementsByTagName('div')[1];
    
    if(elt.getAttribute("class")=="off")
    {
        contentElt.style.display='block';
        elt.setAttribute("class","on");        
    }
    else
    {
        contentElt.style.display='none';
        elt.setAttribute("class","off");
    }
} 

function toggleExpandSimple(elt)
{
    // header(0) and content(1)
    contentElt=elt.parentNode.getElementsByTagName('div')[1];
    
    if(elt.getAttribute("class")=="off")
    {
        contentElt.style.display="none";
        elt.setAttribute("class","on");
    }
    else
    {
        contentElt.style.display="block";
        elt.setAttribute("class","off");
    }
} 

function toggleExpandAjax(address,elt)
{
    // header(0) and content(1)
    contentElt=elt.parentNode.getElementsByTagName('div')[1];
    
    if(elt.getAttribute("class")=="off")
    {
        contentElt.innerHTML=" ";
        elt.setAttribute("class","on");
    }
    else
    {
        new Ajax.Request(address,
                 {method:'get',
                 onSuccess:function(transport){
                    var T=transport.responseText;
                    var pos1=T.indexOf('<pre');
                    var pos2=T.lastIndexOf('</pre');
                    if ((pos1 !=-1) && (pos2 > pos1))
                        T=T.substring(pos1,pos2+6);
                    contentElt.innerHTML=T;
                 },
                 onFailure:function(){contentElt.innerHTML="Could not access content"}
                 });
        elt.setAttribute("class","off");
    }
} 